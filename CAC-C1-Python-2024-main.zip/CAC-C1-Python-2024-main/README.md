# CAC-C1-Pytho-2024
# Proyecto codo a codo. 
# Realizado el primer cuatrimestre del año 2024
# 
Partes a realizar

1- Front End (HTML , CSS Y JS (VUE))
2- Back End (Python)


